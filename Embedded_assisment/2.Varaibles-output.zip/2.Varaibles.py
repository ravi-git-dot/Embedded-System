section_a = 35
section_b = 20
section_c = 24


total = section_a + section_b + section_c
txt = "Total students in all sections ="

print(txt, total)
