from my_calculator import Calc

Calc.add(24,56)
Calc.sub(34, 6)
Calc.mul(34, 12)
Calc.div(56, 9)