import machine
import utime

from chittiSat.pressure import *
from chittiSat.assistant import *

i2c = machine.I2C(0, scl = machine.Pin(1), sda = machine.Pin(0))

devices = i2c.scan()

if devices:
    print(devices)
    
bmp = BMP280(i2c)

calibrate.pressure(BMP280)

while True:
    pressure = bmp.pressure
    temperature = bmp.temperature
    
    #print(f"Pressure value is : {pressure - 150 }")
    #print(f"Temperature value is : {temperature}")
    
    dashboard.sendPressure(pressure, temperature)  
    utime.sleep(1)
